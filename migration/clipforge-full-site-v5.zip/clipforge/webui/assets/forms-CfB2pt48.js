import"./react-vendor-BqivNswc.js";
